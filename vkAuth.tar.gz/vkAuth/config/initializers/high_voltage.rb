HighVoltage.configure do |config|
  config.home_page = 'home'
end